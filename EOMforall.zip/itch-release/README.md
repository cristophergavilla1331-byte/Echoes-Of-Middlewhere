# Shipping Echoes of Middlewhere to itch.io

Your game has zero real dependencies (everything it imports is Python's
standard library). The only actual problem is that itch.io players don't
have Python installed and won't want to. This repo turns your single
`.py` file into a double-clickable Windows .exe, a Mac launcher, and a
Linux binary — automatically, using GitHub's own machines, so you don't
need to own a Windows PC or a Mac.

## One-time setup

1. Create a new GitHub repo (public or private, doesn't matter).
2. Put `EOMwin.py` and this whole `.github/` folder in the root of that repo.
3. Push it:
   ```
   git init
   git add .
   git commit -m "initial commit"
   git branch -M main
   git remote add origin <your-repo-url>
   git push -u origin main
   ```

That's it. No further setup needed on your machine.

## Building

Either:
- **Push a version tag** — this triggers the build automatically:
  ```
  git tag v1.0.0
  git push origin v1.0.0
  ```
- **Or trigger it manually**: on GitHub, go to your repo → **Actions** tab →
  "Build Echoes of Middlewhere" → **Run workflow**.

Either way, three jobs run in parallel (real Windows, real macOS, real
Ubuntu machines, all provided free by GitHub), each producing a
standalone build. Takes a couple minutes.

## Getting your builds

Go to the **Actions** tab → click the completed run → scroll to
**Artifacts** at the bottom. You'll see:
- `EchoesOfMiddlewhere-Windows`
- `EchoesOfMiddlewhere-Mac`
- `EchoesOfMiddlewhere-Linux`

Download and unzip each one.

## Uploading to itch.io

1. On your itch.io dashboard, create a new project (or edit your existing one).
2. Under **Uploads**, click **Upload files** and add all three zip files
   (or the unzipped folders — itch.io accepts both, zipped is safer for upload size).
3. For **each** uploaded file, check the matching platform box that appears
   next to it (Windows / macOS / Linux). This is what makes itch.io show
   the right "Download for Windows" button to each visitor automatically.
4. Leave **"This file will be played in the browser"** unchecked — this
   isn't a web build, it's a native download.
5. Save and publish.

## Playing on each platform (what to tell your players)

- **Windows**: unzip, double-click `EchoesOfMiddlewhere.exe`. A console
  window opens automatically and the game just runs. Windows SmartScreen
  may show an "unrecognized app" warning the first time (unsigned exe) —
  tell players to click "More info" → "Run anyway." This is normal for
  small indie games without a paid code-signing certificate.
- **Mac**: unzip, double-click **"Play EchoesOfMiddlewhere.command."**
  This is a tiny launcher that opens Terminal and runs the game for them
  (a raw double-clicked Unix binary won't show anything on Mac — this
  file fixes that). macOS Gatekeeper will likely block it the first time
  ("cannot be opened because it is from an unidentified developer") —
  players should right-click → Open, then confirm, once.
- **Linux**: unzip, then either double-click `run.sh` (if their file
  manager supports "run in terminal") or open a terminal in that folder
  and run `./run.sh`.

## A couple of things worth knowing

- **Save files**: the game writes `slot1.dat` / `slot2.dat` / `slot3.dat`
  next to wherever it's run from. That's fine for normal double-click use
  on all three platforms, just know saves live alongside the executable,
  not in a system save-folder.
- **Antivirus false positives**: PyInstaller onefile executables
  occasionally get flagged by some antivirus engines simply because
  self-extracting binaries look similar to malware droppers to heuristic
  scanners — this is a well-known false-positive pattern with PyInstaller
  specifically, not a sign anything is wrong with your code.
- **Updating the game later**: edit `EOMwin.py`, commit, push a new tag
  (e.g. `v1.0.1`), download the new artifacts, re-upload to itch.io.

## Optional: auto-publish straight to itch.io

Itch.io has an official CLI tool called `butler` that can push builds
directly from GitHub Actions with no manual download/upload step. If you
want that later, get an API key from https://itch.io/user/settings/api-keys,
add it as a repo secret named `ITCH_API_KEY`, and add a `butler push` step
to each build job. Not required to ship — just a convenience if you end up
updating the game often.
